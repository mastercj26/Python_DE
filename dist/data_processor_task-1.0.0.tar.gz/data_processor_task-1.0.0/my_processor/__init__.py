"""
my_processor
============
A small, modular Data Processor utility built for the Python Core
Concepts training assignment.
Exposes the main public classes so users can do:
from my_processor import Member, InvalidMemberDataError
"""
from .core import Member, InvalidMemberDataError
from .utils import clean_name, validate_email, validate_phone
__all__ = ["Member",
"InvalidMemberDataError",
"clean_name",
"validate_email",
"validate_phone",
]
__version__ = "1.0.0