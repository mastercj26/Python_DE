"""
utils.py
========
Helper logic for the Data Processor utility: regex-based validation
and small data-cleaning helpers.
Covers the "Regular Expressions" and part of the "Python Functions"
requirements from the assignment.
"""
import re
# --- Regex patterns -------------------------------------------------
# A reasonably strict (but not overly complex) email pattern:
# local-part@domain.tld
# The domain is built from one or more "label." groups (a label
# cannot be empty or start/end with '.', which rejects things like
# "example@...com") followed by a final top-level domain of at
# least 2 letters.
EMAIL_PATTERN = re.compile(
r"^[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z]{2,}$"
)
# Matches phone numbers in the "555-0101" style used in the sample
# data, and also allows optional country code / different separators,
# e.g. "555-0101", "555.0101", "+1-555-0101".
PHONE_PATTERN = re.compile(
r"^(\+\d{1,3}[- .]?)?\d{3}[- .]?\d{4}$"
)
def clean_name(raw_name):
"""
Clean a raw name string using slicing/whitespace stripping.
- Strips leading/trailing whitespace.
- Collapses internal multiple spaces into a single space.
- Title-cases the result (e.g. "john doe" -> "John Doe").
Demonstrates simple string slicing/cleaning as required by the
"Data Structures" / "Python Functions" sections.
"""
if not isinstance(raw_name, str):
return ""
# Strip outer whitespace (slicing-based trim of stray characters
# is also demonstrated here for illustration).
name = raw_name.strip()
# Collapse internal whitespace.
name = re.sub(r"\s+", " ", name)
return name.title()
def validate_email(email):
"""
Validate an email address using a regular expression.
Returns True if the email looks valid, False otherwise.
"""
if not isinstance(email, str):
return False
return bool(EMAIL_PATTERN.match(email.strip()))
def validate_phone(phone):
"""
Validate a phone number using a regular expression.
Accepts formats like "555-0101", "555.0101", "5550101", and
"+1-555-0101".
"""
if not isinstance(phone, str):
return False
return bool(PHONE_PATTERN.match(phone.strip()))