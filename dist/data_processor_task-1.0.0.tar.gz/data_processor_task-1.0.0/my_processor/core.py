
from .utils import clean_name, validate_email, validate_phone
class InvalidMemberDataError(Exception):
"""
Custom exception raised when raw member data is malformed
(e.g. invalid email format, invalid phone format, or missing
required fields).
"""
def __init__(self, member_name, reason):
self.member_name = member_name
self.reason = reason
message = f"Invalid data for member '{member_name}': {reason}"
super().__init__(message)
class Member:
"""
Represents a single member profile.
Demonstrates OOP: __init__ constructor, self reference, and a
custom __repr__/__str__ for readable printing.
"""
def __init__(self, name, email, phone):
# Basic presence checks -> raise our custom exception on
# missing/malformed data, as required by the assignment.
if not name or not isinstance(name, str):
raise InvalidMemberDataError(name or "Unknown", "missing or invalid name")
if not validate_email(email):
raise InvalidMemberDataError(name, "invalid email format")
if not validate_phone(phone):
raise InvalidMemberDataError(name, "invalid phone format")
self.name = clean_name(name)
self.email = email.strip().lower()
self.phone = phone.strip()
def __str__(self):
return f"Member(name='{self.name}', email='{self.email}', phone='{self.phone}')"
def __repr__(self):
return self.__str__()
def to_dict(self):
"""Return the member as a plain dictionary."""
return {"name": self.name, "email": self.email, "phone": self.phone}
def process_raw_members(raw_members):
"""
Process a list of raw member dictionaries into a list of
validated Member objects.
- Uses try/except to catch our custom InvalidMemberDataError as
well as standard Python errors (KeyError, ValueError, etc.)
for genuinely malformed input.
- Prints a processing log matching the assignment's expected
output format.
Returns a tuple: (list_of_successful_members, error_count)
"""
successful_members = []
error_count = 0
for raw in raw_members:
# Use .get() so a missing key doesn't itself raise a
# KeyError before we can attribute a friendly name.
name = raw.get("name", "InvalidData")
email = raw.get("email")
phone = raw.get("phone")
print(f"Processing member: {name}...", end=" ")
try:
member = Member(name, email, phone)
except InvalidMemberDataError as exc:
print("Validation Failed.")
print(f"Error: {exc.reason} for member '{name}'. Skipping.")
error_count += 1
continue
except (KeyError, ValueError, TypeError) as exc:
# Catch standard/system errors too, per the assignment.
print("Validation Failed.")
print(f"Error: Unexpected error for member '{name}': {exc}. Skipping.")
error_count += 1
continue
print("Validation Successful.")
successful_members.append(member)
print(f"Summary: {len(successful_members)} members processed successfully.")
return successful_members, error_count
# --- Functional Programming examples ---------------------------------
def filter_members_by_domain(members, domain):
"""
Use a lambda with filter() to return only members whose email
belongs to the given domain (e.g. "example.com").
"""
return list(filter(lambda m: m.email.endswith(f"@{domain}"), members))
def get_all_names(members):
"""
Use a lambda with map() to extract just the names from a list
of Member objects.
"""
return list(map(lambda m: m.name, members))